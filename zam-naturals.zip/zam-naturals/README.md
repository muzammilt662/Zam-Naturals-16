# ZAM NATURALS storefront (React + Vite + TypeScript)

## Run
    npm install
    npm run dev        # http://localhost:5173
    npm run build      # outputs dist/
    npm run preview    # test the production build

## Replace the hero video
Put your MP4 at `public/videos/honey-hero.mp4` and a still frame at `public/videos/honey-hero-poster.jpg`.
Keep it muted, ~720p, ideally under 2 MB:
    ffmpeg -i input.mp4 -an -vf scale=720:-2 -c:v libx264 -crf 28 -movflags +faststart public/videos/honey-hero.mp4
`src/components/HeroVideo.tsx` falls back to the poster on errors, data-saver mode and reduced-motion.

## Replace product images / edit products
Edit `src/data/products.ts` only. Drop photos into `public/images/products/` and update the `image` paths (current files are SVG placeholders). Prices, sizes and ingredients are placeholders.

## Still needed for a real store
- Backend (Node API, or Shopify/Medusa/WooCommerce headless) to create orders and keep prices server-side
- Payment gateway (Razorpay, Stripe, etc.): public key in `VITE_PAYMENT_PUBLIC_KEY`; secret key and webhook secret on the server only
- Database for orders and customers; transactional email (order confirmation)
- Newsletter provider (Mailchimp, Klaviyo, etc.) behind a backend endpoint
- Shipping rates and tax rules; legal pages (privacy, returns, terms); real contact details and social links
- Food licence or certification claims only once you actually hold them
- Analytics and cookie consent where required
