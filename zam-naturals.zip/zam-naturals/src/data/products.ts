// Single source of truth for products. Replace image paths with real photos in /public/images/products.
export type Category = "Original" | "Chocolate" | "Coconut";
export interface Product {
  id: string; name: string; category: Category; short: string; description: string;
  price: number; size: string; image: string; ingredients: string[];
}
export const CURRENCY = "₹"; // change to your currency
export const categories: ("All" | Category)[] = ["All", "Original", "Chocolate", "Coconut"];
// Placeholder prices, sizes and ingredient lists: confirm against your real recipe and labels before launch.
export const products: Product[] = [
  { id: "original-honey-mix", name: "Original Honey Mix", category: "Original", size: "350 g jar", price: 599,
    short: "Almonds, cashews, raisins, dates, figs and seeds in honey.",
    description: "Our signature blend. Whole nuts and dried fruit rest in honey so every spoonful has crunch, chew and sweetness.",
    image: "/images/products/original.svg", ingredients: ["Honey","Almonds","Cashews","Raisins","Dates","Figs","Mixed seeds"] },
  { id: "chocolate-honey-mix", name: "Chocolate Honey Mix", category: "Chocolate", size: "350 g jar", price: 649,
    short: "The classic blend with a rich cocoa note.",
    description: "The original dry fruit and honey blend finished with cocoa for a deeper, dessert-like flavour.",
    image: "/images/products/chocolate.svg", ingredients: ["Honey","Almonds","Cashews","Raisins","Dates","Cocoa","Mixed seeds"] },
  { id: "coconut-honey-mix", name: "Coconut Honey Mix", category: "Coconut", size: "350 g jar", price: 649,
    short: "Nuts and fruit with toasted coconut and honey.",
    description: "A lighter, tropical take on the blend, with coconut folded through honey, nuts and dried fruit.",
    image: "/images/products/coconut.svg", ingredients: ["Honey","Almonds","Cashews","Raisins","Dates","Coconut","Mixed seeds"] },
];
