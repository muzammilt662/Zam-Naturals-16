import { lazy, Suspense, useEffect, useState } from "react";
import Header from "./components/Header";
import Cart from "./components/Cart";
import Products from "./components/Products";
import { Hero, Trust, Story, Why, Newsletter, Footer } from "./components/Sections";
const Checkout = lazy(() => import("./components/Checkout"));
export default function App() {
  const [view, setView] = useState<"home" | "checkout">("home");
  const [target, setTarget] = useState<string | null>(null);
  const go = (id: string) => { setView("home"); setTarget(id); };
  useEffect(() => {
    if (view === "home" && target) {
      document.getElementById(target)?.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
      setTarget(null);
    }
  }, [view, target]);
  useEffect(() => {
    document.title = view === "checkout" ? "Checkout | ZAM NATURALS" : "ZAM NATURALS | Premium Honey and Dry Fruit Blends";
    if (view === "checkout") scrollTo(0, 0);
  }, [view]);
  return (<>
    <Header go={go} />
    <main>
      {view === "home" ? (<><Hero go={go} /><Trust /><Products /><Story /><Why /><Newsletter /></>)
        : <Suspense fallback={<p className="section">Loading checkout…</p>}><Checkout back={() => go("shop")} /></Suspense>}
    </main>
    <Footer /><Cart checkout={() => setView("checkout")} />
  </>);
}
