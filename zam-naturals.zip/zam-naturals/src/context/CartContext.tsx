import { createContext, useContext, useEffect, useMemo, useReducer, useState, type ReactNode } from "react";
import { products } from "../data/products";

type Lines = Record<string, number>;
type Action = { t: "add"; id: string; qty: number } | { t: "set"; id: string; qty: number } | { t: "remove"; id: string } | { t: "clear" };
const KEY = "zam-cart";
function without(s: Lines, id: string): Lines { const r = { ...s }; delete r[id]; return r; }
function reducer(s: Lines, a: Action): Lines {
  switch (a.t) {
    case "add": return { ...s, [a.id]: Math.min(20, (s[a.id] ?? 0) + a.qty) };
    case "set": return a.qty <= 0 ? without(s, a.id) : { ...s, [a.id]: Math.min(20, a.qty) };
    case "remove": return without(s, a.id);
    case "clear": return {};
  }
}
function load(): Lines { try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { return {}; } }

interface Ctx {
  lines: { id: string; qty: number; name: string; price: number; image: string }[];
  count: number; subtotal: number; open: boolean; setOpen: (v: boolean) => void;
  add: (id: string, qty?: number) => void; setQty: (id: string, qty: number) => void; remove: (id: string) => void; clear: () => void;
}
const C = createContext<Ctx | null>(null);
export const useCart = () => { const c = useContext(C); if (!c) throw new Error("CartProvider missing"); return c; };

export function CartProvider({ children }: { children: ReactNode }) {
  const [s, d] = useReducer(reducer, undefined, load);
  const [open, setOpen] = useState(false);
  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* storage unavailable */ } }, [s]);
  const value = useMemo<Ctx>(() => {
    const lines = Object.entries(s).flatMap(([id, qty]) => { const p = products.find(x => x.id === id); return p ? [{ id, qty, name: p.name, price: p.price, image: p.image }] : []; });
    return {
      lines, open, setOpen,
      count: lines.reduce((n, l) => n + l.qty, 0),
      subtotal: lines.reduce((n, l) => n + l.qty * l.price, 0),
      add: (id, qty = 1) => { d({ t: "add", id, qty }); setOpen(true); },
      setQty: (id, qty) => d({ t: "set", id, qty }),
      remove: id => d({ t: "remove", id }),
      clear: () => d({ t: "clear" }),
    };
  }, [s, open]);
  return <C.Provider value={value}>{children}</C.Provider>;
}
