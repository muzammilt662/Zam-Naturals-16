import { useState } from "react";
import { CURRENCY } from "../data/products";
import { useCart } from "../context/CartContext";
type F = { name: string; email: string; phone: string; address: string; city: string; pin: string };
const blank: F = { name: "", email: "", phone: "", address: "", city: "", pin: "" };
function validate(f: F) {
  const e: Partial<F> = {};
  if (f.name.trim().length < 2) e.name = "Enter your full name.";
  if (!/^\S+@\S+\.\S+$/.test(f.email)) e.email = "Enter a valid email address.";
  if (!/^\+?[0-9 ]{10,14}$/.test(f.phone)) e.phone = "Enter a phone number with 10 to 14 digits.";
  if (f.address.trim().length < 6) e.address = "Enter your street address.";
  if (f.city.trim().length < 2) e.city = "Enter your city.";
  if (!/^[0-9]{5,6}$/.test(f.pin)) e.pin = "Enter a 5 or 6 digit postal code.";
  return e;
}
export default function Checkout({ back }: { back: () => void }) {
  const { lines, subtotal } = useCart();
  const [f, setF] = useState<F>(blank); const [err, setErr] = useState<Partial<F>>({}); const [ok, setOk] = useState(false);
  const field = (k: keyof F, label: string, type = "text") => (
    <label>{label}<input type={type} value={f[k]} aria-invalid={!!err[k]} aria-describedby={err[k] ? k + "-e" : undefined} onChange={e => setF({ ...f, [k]: e.target.value })} />
      {err[k] && <span className="err" id={k + "-e"} role="alert">{err[k]}</span>}</label>);
  const submit = (e: React.FormEvent) => {
    e.preventDefault(); const v = validate(f); setErr(v);
    // TODO: POST to your backend (create order + payment session). Nothing is sent or charged here.
    setOk(Object.keys(v).length === 0);
  };
  return (
    <section className="section checkout" aria-labelledby="co">
      <h2 id="co">Checkout</h2>
      {lines.length === 0 ? <div className="empty"><p>Your cart is empty.</p><button className="btn solid" onClick={back}>Back to shop</button></div> : (
        <div className="co-grid">
          <form onSubmit={submit} noValidate>
            {field("name", "Full name")}{field("email", "Email", "email")}{field("phone", "Phone", "tel")}
            {field("address", "Street address")}{field("city", "City")}{field("pin", "Postal code")}
            <p className="note">Online payment is not connected yet. This form validates your details only. No order is placed and no payment is taken.</p>
            {ok && <p className="ok" role="status">Details look good. Connect a payment backend to complete real orders.</p>}
            <button className="btn solid" type="submit">Continue to payment</button>
          </form>
          <aside className="summary"><h3>Order summary</h3>
            <ul>{lines.map(l => <li key={l.id}><span>{l.name} × {l.qty}</span><span>{CURRENCY}{l.qty * l.price}</span></li>)}</ul>
            <p className="sub"><span>Subtotal</span><strong>{CURRENCY}{subtotal}</strong></p><button className="link" onClick={back}>Keep shopping</button></aside>
        </div>)}
    </section>
  );
}
