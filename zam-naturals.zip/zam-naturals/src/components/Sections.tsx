import { useState } from "react";
import HeroVideo from "./HeroVideo";
export function Hero({ go }: { go: (t: string) => void }) {
  return (
    <section className="hero" id="top">
      <div className="hero-copy">
        <h1>Nature in Every Spoon.</h1>
        <p>Honey poured over almonds, cashews, raisins, dates, figs and seeds. Simple ingredients, blended with care and packed in glass.</p>
        <div className="row"><button className="btn solid" onClick={() => go("shop")}>Shop Now</button><button className="btn ghost" onClick={() => go("story")}>Discover Our Story</button></div>
      </div>
      <HeroVideo />
    </section>
  );
}
const values = [["Honey first", "Every jar starts with honey as the base."], ["Whole ingredients", "Nuts, fruit and seeds you can see in the jar."], ["Three flavours", "Original, Chocolate and Coconut."], ["Packed in glass", "Clear jars so you can see what you are buying."]];
export const Trust = () => (<section className="trust" aria-label="Brand values">{values.map(([t, d]) => <div key={t}><h3>{t}</h3><p>{d}</p></div>)}</section>);
export const Story = () => (
  <section id="story" className="section story"><div><h2>Our story</h2>
    <p>ZAM NATURALS began with a simple idea: honey and dry fruit belong together. We pair honey with whole nuts, sweet dried fruit and seeds, then let the jar do the talking.</p>
    <p>Replace this text with your own founding story, sourcing details and the people behind the brand.</p></div></section>
);
export const Why = () => (
  <section className="section why"><h2>Why choose ZAM NATURALS</h2>
    <ul><li><strong>Ready to eat.</strong> Spoon it over yogurt, oats or toast, or eat it straight from the jar.</li>
      <li><strong>Clear ingredient lists.</strong> Each product page shows exactly what goes in.</li>
      <li><strong>A mix for every taste.</strong> Choose classic, cocoa or coconut.</li></ul></section>
);
export function Newsletter() {
  const [em, setEm] = useState(""); const [s, setS] = useState<"idle" | "bad" | "ok">("idle");
  return (
    <section className="section news"><h2>Get new flavours first</h2><p>Join the list for launches and offers.</p>
      <form onSubmit={e => { e.preventDefault(); /* TODO: send to your email provider via backend */ setS(/^\S+@\S+\.\S+$/.test(em) ? "ok" : "bad"); }} noValidate>
        <label className="sr" htmlFor="nl">Email address</label>
        <input id="nl" type="email" placeholder="you@example.com" value={em} onChange={e => setEm(e.target.value)} aria-invalid={s === "bad"} />
        <button className="btn solid">Subscribe</button></form>
      {s === "bad" && <p className="err" role="alert">Enter a valid email address.</p>}
      {s === "ok" && <p className="ok" role="status">Thanks. Email sign-up is not connected yet, so nothing was saved.</p>}
    </section>
  );
}
export const Footer = () => (
  <footer id="contact" className="footer">
    <div><strong className="logo">ZAM NATURALS</strong><p>Premium honey and dry fruit blends.</p></div>
    <div><h3>Contact</h3><p>hello@yourdomain.com<br />+00 000 000 0000<br />Your address here</p></div>
    <div><h3>Follow</h3><p><a href="#">Instagram</a><br /><a href="#">Facebook</a><br /><a href="#">YouTube</a></p></div>
    <div><h3>Policies</h3><p><a href="#">Shipping</a><br /><a href="#">Returns</a><br /><a href="#">Privacy</a></p></div>
    <small>© {new Date().getFullYear()} ZAM NATURALS. All rights reserved.</small>
  </footer>
);
