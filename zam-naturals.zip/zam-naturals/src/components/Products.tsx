import { useEffect, useMemo, useState } from "react";
import { categories, CURRENCY, products, type Product } from "../data/products";
import { useCart } from "../context/CartContext";

function Qty({ v, set }: { v: number; set: (n: number) => void }) {
  return (
    <div className="qty" role="group" aria-label="Quantity">
      <button type="button" onClick={() => set(Math.max(1, v - 1))} aria-label="Decrease quantity">−</button>
      <output>{v}</output>
      <button type="button" onClick={() => set(Math.min(20, v + 1))} aria-label="Increase quantity">+</button>
    </div>
  );
}
function Card({ p, onOpen }: { p: Product; onOpen: () => void }) {
  const { add } = useCart(); const [q, setQ] = useState(1);
  return (
    <article className="card">
      <button className="card-img" onClick={onOpen} aria-label={`View details for ${p.name}`}><img src={p.image} alt={p.name} loading="lazy" width={600} height={600} /></button>
      <div className="card-body">
        <h3>{p.name}</h3><p>{p.short}</p>
        <p className="price">{CURRENCY}{p.price} <span>{p.size}</span></p>
        <div className="row"><Qty v={q} set={setQ} /><button className="btn solid" onClick={() => { add(p.id, q); setQ(1); }}>Add to cart</button></div>
      </div>
    </article>
  );
}
function Modal({ p, close }: { p: Product; close: () => void }) {
  const { add } = useCart(); const [q, setQ] = useState(1);
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === "Escape") close(); }; addEventListener("keydown", k); return () => removeEventListener("keydown", k); }, [close]);
  return (
    <div className="overlay" onClick={close}>
      <div className="modal" role="dialog" aria-modal="true" aria-label={p.name} onClick={e => e.stopPropagation()}>
        <img src={p.image} alt={p.name} />
        <div>
          <h3>{p.name}</h3><p className="price">{CURRENCY}{p.price} <span>{p.size}</span></p>
          <p>{p.description}</p>
          <p><strong>Ingredients:</strong> {p.ingredients.join(", ")}</p>
          <div className="row"><Qty v={q} set={setQ} /><button className="btn solid" onClick={() => { add(p.id, q); close(); }}>Add to cart</button></div>
          <p><button className="link" onClick={close}>Close</button></p>
        </div>
      </div>
    </div>
  );
}
export default function Products() {
  const [cat, setCat] = useState<string>("All"); const [q, setQ] = useState(""); const [sel, setSel] = useState<Product | null>(null);
  const list = useMemo(() => products.filter(p => (cat === "All" || p.category === cat) && (p.name + p.short).toLowerCase().includes(q.trim().toLowerCase())), [cat, q]);
  return (
    <section id="shop" className="section">
      <h2>Our honey mixes</h2>
      <div className="filters">
        <div role="group" aria-label="Filter by category">{categories.map(c => <button key={c} className={"chip" + (c === cat ? " on" : "")} aria-pressed={c === cat} onClick={() => setCat(c)}>{c}</button>)}</div>
        <label className="search"><span className="sr">Search products</span><input type="search" placeholder="Search products" value={q} onChange={e => setQ(e.target.value)} /></label>
      </div>
      {list.length ? <div className="grid">{list.map(p => <Card key={p.id} p={p} onOpen={() => setSel(p)} />)}</div>
        : <p className="empty">No products match “{q}”. Clear the search or choose another category.</p>}
      {sel && <Modal p={sel} close={() => setSel(null)} />}
    </section>
  );
}
