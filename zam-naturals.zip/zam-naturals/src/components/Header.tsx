import { useState } from "react";
import { useCart } from "../context/CartContext";
export default function Header({ go }: { go: (to: string) => void }) {
  const { count, setOpen } = useCart();
  const [menu, setMenu] = useState(false);
  const nav = (to: string) => (e: React.MouseEvent) => { e.preventDefault(); setMenu(false); go(to); };
  return (
    <>
      <div className="announce">Free shipping on orders above ₹999 (edit this message in Header.tsx)</div>
      <header className="header">
        <a href="#top" className="logo" onClick={nav("top")} aria-label="ZAM NATURALS home">ZAM NATURALS</a>
        <button className="menu-btn" aria-expanded={menu} aria-controls="nav" onClick={() => setMenu(!menu)}>{menu ? "Close" : "Menu"}</button>
        <nav id="nav" className={menu ? "open" : ""} aria-label="Main">
          <a href="#top" onClick={nav("top")}>Home</a>
          <a href="#shop" onClick={nav("shop")}>Shop</a>
          <a href="#story" onClick={nav("story")}>Our Story</a>
          <a href="#contact" onClick={nav("contact")}>Contact</a>
        </nav>
        <button className="cart-btn" onClick={() => setOpen(true)} aria-label={`Open cart, ${count} items`}>Cart <span className="badge">{count}</span></button>
      </header>
    </>
  );
}
