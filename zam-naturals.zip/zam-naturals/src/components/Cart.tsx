import { CURRENCY } from "../data/products";
import { useCart } from "../context/CartContext";
export default function Cart({ checkout }: { checkout: () => void }) {
  const { open, setOpen, lines, subtotal, setQty, remove } = useCart();
  if (!open) return null;
  return (
    <div className="overlay" onClick={() => setOpen(false)}>
      <aside className="drawer" role="dialog" aria-modal="true" aria-label="Shopping cart" onClick={e => e.stopPropagation()}>
        <div className="drawer-head"><h2>Your cart</h2><button className="link" onClick={() => setOpen(false)}>Close</button></div>
        {lines.length === 0 ? (
          <div className="empty"><p>Your cart is empty.</p><a className="btn solid" href="#shop" onClick={() => setOpen(false)}>Browse the shop</a></div>
        ) : (<>
          <ul className="lines">{lines.map(l => (
            <li key={l.id}><img src={l.image} alt="" width={64} height={64} />
              <div><strong>{l.name}</strong><span>{CURRENCY}{l.price}</span>
                <div className="qty"><button onClick={() => setQty(l.id, l.qty - 1)} aria-label={`Decrease ${l.name}`}>−</button><output>{l.qty}</output><button onClick={() => setQty(l.id, l.qty + 1)} aria-label={`Increase ${l.name}`}>+</button></div></div>
              <button className="link" onClick={() => remove(l.id)}>Remove</button></li>))}</ul>
          <div className="drawer-foot"><p className="sub"><span>Subtotal</span><strong>{CURRENCY}{subtotal}</strong></p><small>Shipping and taxes are calculated at checkout.</small>
            <button className="btn solid full" onClick={() => { setOpen(false); checkout(); }}>Go to checkout</button></div>
        </>)}
      </aside>
    </div>
  );
}
