import { useEffect, useRef, useState } from "react";
// Replace /public/videos/honey-hero.mp4 (and the poster) to change the hero. Video is skipped on data-saver connections.
const SRC = "/videos/honey-hero.mp4", POSTER = "/videos/honey-hero-poster.jpg";
const ALT = "Honey dripping from a honeycomb into a jar of nuts and dried fruit";
export default function HeroVideo() {
  const ref = useRef<HTMLVideoElement>(null);
  const [failed, setFailed] = useState(false);
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const saveData = (navigator as Navigator & { connection?: { saveData?: boolean } }).connection?.saveData === true;
  const useVideo = !failed && !reduce && !saveData;
  useEffect(() => { ref.current?.play().catch(() => setFailed(true)); }, []);
  return (
    <div className="hero-media">
      {useVideo ? (
        <video ref={ref} className="hero-video" poster={POSTER} muted loop autoPlay playsInline preload="metadata" aria-label={ALT} onError={() => setFailed(true)}>
          <source src={SRC} type="video/mp4" />
        </video>
      ) : (
        <img className="hero-video" src={POSTER} alt={ALT} onError={e => (e.currentTarget.style.visibility = "hidden")} />
      )}
    </div>
  );
}
